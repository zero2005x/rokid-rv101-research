/* OnePlus 15 (PLK110) — SM8845 / Snapdragon 8s Elite */

OFFSETS_ENTRY("6.12.23-android16-5-gb2a876903b49-ab14541642-4k",  /* PLK110_16.0.8.301 (untested) */
  .off_init_task=0x023ECF00, .off_init_cred=0x02402A68, .off_init_uts_ns=0x02574650,
  .off_empty_zero_page=0x02614000, .off_root_task_group=0x0261C580,
  .off_selinux_enforcing=0x026684F0, .off_kptr_restrict=0x023EB638,
  .off_selinux_blob_sizes=0x018304E8, .off_security_hook_heads=0,
  .off_kmalloc_caches=0x0182A4C0, .off_anon_pipe_buf_ops=0x0120ED88,
  .off_ashmem_misc_fops=0, .off_ashmem_fops=0x02695A88,
  .off_ashmem_ioctl=0x00D7E6E4, .off_ashmem_compat_ioctl=0x00D7ECCC,
  .off_ashmem_mmap=0x00D7ED48, .off_ashmem_open=0x00D7EDA4,
  .off_ashmem_release=0x00D7E7A4, .off_ashmem_show_fdinfo=0x00D7ECA4,
  .off_configfs_read_iter=0x00511F50, .off_configfs_bin_write_iter=0x00512184,
  .off_copy_splice_read=0x0048E190, .off_noop_llseek=0x0043B7D4,
  .off_cap_capable_active=0x02662B50,
  .off_slide_nfulnl_logger=0x023E2198, .off_slide_loggers_0_1=0x023E20E8,
  .off_slide_boot_id=0x02689868,
),
