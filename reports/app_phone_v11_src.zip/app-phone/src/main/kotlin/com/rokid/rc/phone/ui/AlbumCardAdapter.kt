package com.rokid.rc.phone.ui

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.rokid.rc.phone.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** 相簿卡片（2 欄大封面）。 */
data class AlbumCard(
    val id: String,
    val name: String,
    val countText: String,
    val subText: String? = null,
    val empty: Boolean = false
)

class AlbumCardAdapter(
    private var items: List<AlbumCard> = emptyList(),
    private val coverLoader: suspend (AlbumCard) -> Bitmap? = { null },
    private val onClick: (AlbumCard) -> Unit = {},
    private val onLongClick: (AlbumCard) -> Unit = {}
) : RecyclerView.Adapter<AlbumCardAdapter.VH>() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cover: ImageView = v.findViewById(R.id.ivCover)
        val name: TextView = v.findViewById(R.id.tvName)
        val count: TextView = v.findViewById(R.id.tvCount)
        val emptyIcon: View = v.findViewById(R.id.ivEmpty)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_album_card, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val a = items[position]
        h.name.text = a.name
        h.count.text = a.countText
        h.cover.setImageDrawable(null)
        val showEmpty = a.empty
        h.emptyIcon.visibility = if (showEmpty) View.VISIBLE else View.INVISIBLE
        h.cover.visibility = if (showEmpty) View.INVISIBLE else View.VISIBLE
        if (!showEmpty) {
            val job = Job()
            h.itemView.setTag(R.id.cover_job, job)
            scope.launch(job) {
                val bmp = coverLoader(a)
                if (bmp != null && h.itemView.getTag(R.id.cover_job) === job) {
                    h.cover.setImageBitmap(bmp)
                }
            }
        }
        h.itemView.setOnClickListener { onClick(a) }
        h.itemView.setOnLongClickListener {
            onLongClick(a)
            true
        }
    }

    override fun onViewRecycled(h: VH) {
        super.onViewRecycled(h)
        (h.itemView.getTag(R.id.cover_job) as? Job)?.cancel()
        h.itemView.setTag(R.id.cover_job, null)
    }

    fun submit(list: List<AlbumCard>) {
        items = list
        notifyDataSetChanged()
    }

    fun release() {
        scope.cancel()
    }
}
