package com.rokid.rc.phone

import com.rokid.rc.phone.util.LocalStore

import android.bluetooth.BluetoothDevice
import android.content.Context
import com.rokid.rc.phone.net.BluetoothClient
import com.rokid.rc.shared.protocol.Album
import com.rokid.rc.shared.protocol.MediaItem
import com.rokid.rc.shared.protocol.Msg
import com.rokid.rc.shared.protocol.MsgType
import com.rokid.rc.shared.protocol.RootMode
import com.rokid.rc.shared.protocol.Status
import java.io.File
import java.io.IOException
import org.json.JSONObject

/** 手機端遠端 API 封裝（單例）。 */
object Remote {
    lateinit var appContext: Context
        private set

    val client = BluetoothClient()
    var device: BluetoothDevice? = null
        private set

    val isConnected: Boolean get() = client.connected

    fun ensureInit(context: Context) {
        if (!::appContext.isInitialized) {
            appContext = context.applicationContext
        }
    }

    suspend fun connect(device: BluetoothDevice): Result<Unit> {
        this.device = device
        return client.connect(device)
    }

    fun disconnect() = client.disconnect()

    /** 若連線已斷，嘗試用已知裝置重連。 */
    private suspend fun ensureConnected(): Boolean {
        if (client.connected) return true
        val d = device ?: return false
        return client.connect(d).isSuccess
    }

    /** 長時指令（跑 ghostlock LPE）的請求逾時。 */
    private const val LONG_TIMEOUT = 600_000L

    private suspend fun request(msg: JSONObject, timeoutMs: Long = 30_000L): JSONObject {
        if (!client.connected) ensureConnected()
        return client.request(msg, timeoutMs)
    }

    private suspend fun requestFile(
        msg: JSONObject,
        dir: File,
        name: String,
        timeoutMs: Long = 120_000L,
        onProgress: ((doneBytes: Long, totalBytes: Long) -> Unit)? = null
    ): Result<File> {
        if (!client.connected) ensureConnected()
        return client.requestFile(msg, dir, name, timeoutMs, onProgress)
    }

    suspend fun status(): Result<Status> = runCatching {
        Status.fromJson(request(Msg.build(MsgType.GET_STATUS)))
    }

    suspend fun setGhostlock(enabled: Boolean): Result<Unit> = runCatching {
        val r = request(Msg.build(MsgType.SET_GHOSTLOCK, 0L, "enabled" to enabled))
        if (Msg.ok(r)) Unit else throw IOException(Msg.error(r) ?: "failed")
    }

    suspend fun setRootMode(mode: RootMode): Result<Unit> = runCatching {
        val r = request(Msg.build(MsgType.SET_ROOT_MODE, 0L, "mode" to mode.name))
        if (Msg.ok(r)) Unit else throw IOException(Msg.error(r) ?: "failed")
    }

    suspend fun acquireRoot(): Result<Boolean> = runCatching {
        val r = request(Msg.build(MsgType.ACQUIRE_ROOT), LONG_TIMEOUT)
        if (Msg.ok(r)) true else throw IOException(Msg.error(r) ?: "failed")
    }

    suspend fun setLed(on: Boolean, color: String = "white"): Result<Unit> = runCatching {
        val r = request(Msg.build(MsgType.SET_LED, 0L, "on" to on, "color" to color), LONG_TIMEOUT)
        if (Msg.ok(r)) Unit else throw IOException(Msg.error(r) ?: "failed")
    }

    /** 查詢眼鏡端權限/SELinux 狀況。 */
    suspend fun deviceInfo(): Result<JSONObject> = runCatching {
        request(Msg.build(MsgType.GET_DEVICE_INFO)).getJSONObject("info")
    }

    suspend fun capturePhoto(): Result<MediaItem> = runCatching {
        val r = request(Msg.build(MsgType.CAPTURE_PHOTO), LONG_TIMEOUT)
        MediaItem.fromJson(r.getJSONObject("media"))
    }

    suspend fun startVideo(): Result<Unit> = runCatching {
        request(Msg.build(MsgType.START_VIDEO))
        Unit
    }

    suspend fun stopVideo(): Result<MediaItem> = runCatching {
        val r = request(Msg.build(MsgType.STOP_VIDEO))
        MediaItem.fromJson(r.getJSONObject("media"))
    }

    suspend fun listAlbums(): Result<List<Album>> = runCatching {
        val r = request(Msg.build(MsgType.LIST_ALBUMS))
        val arr = r.getJSONArray("albums")
        (0 until arr.length()).map { Album.fromJson(arr.getJSONObject(it)) }
    }

    suspend fun createAlbum(name: String): Result<Album> = runCatching {
        val r = request(Msg.build(MsgType.CREATE_ALBUM, 0L, "name" to name))
        if (!Msg.ok(r)) throw IOException(Msg.error(r) ?: "failed")
        Album.fromJson(Msg.data(r)!!.getJSONObject("album"))
    }

    suspend fun renameAlbum(albumId: String, name: String): Result<Unit> = runCatching {
        val r = request(Msg.build(MsgType.RENAME_ALBUM, 0L, "albumId" to albumId, "name" to name))
        if (Msg.ok(r)) Unit else throw IOException(Msg.error(r) ?: "failed")
    }

    suspend fun deleteAlbum(albumId: String): Result<Unit> = runCatching {
        val r = request(Msg.build(MsgType.DELETE_ALBUM, 0L, "albumId" to albumId))
        if (Msg.ok(r)) Unit else throw IOException(Msg.error(r) ?: "failed")
    }

    suspend fun listMedia(albumId: String): Result<List<MediaItem>> = runCatching {
        val r = request(Msg.build(MsgType.LIST_MEDIA, 0L, "albumId" to albumId))
        val arr = r.getJSONArray("items")
        (0 until arr.length()).map { MediaItem.fromJson(arr.getJSONObject(it)) }
    }

    suspend fun deleteMedia(mediaId: String): Result<Unit> = runCatching {
        val r = request(Msg.build(MsgType.DELETE_MEDIA, 0L, "mediaId" to mediaId))
        if (Msg.ok(r)) Unit else throw IOException(Msg.error(r) ?: "failed")
    }

    /** 依檔案大小估算 RFCOMM 傳輸逾時（以 ~60KB/s 保守速率 + 固定緩衝）。 */
    private fun transferTimeout(sizeBytes: Long): Long =
        (sizeBytes * 1000 / 60_000).coerceAtLeast(30_000L) + 45_000L

    suspend fun getThumbnail(mediaId: String, maxW: Int = 320, maxH: Int = 320): Result<File> {
        val dir = File(appContext.cacheDir, "thumbs")
        dir.mkdirs()
        val target = File(dir, "$mediaId.jpg")
        if (target.exists() && target.length() > 0) return Result.success(target)
        return requestFile(
            Msg.build(MsgType.GET_THUMBNAIL, 0L, "mediaId" to mediaId, "maxW" to maxW, "maxH" to maxH),
            dir, "$mediaId.jpg",
            timeoutMs = 120_000L
        )
    }

    suspend fun downloadMedia(
        item: MediaItem,
        albumName: String? = null,
        onProgress: ((doneBytes: Long, totalBytes: Long) -> Unit)? = null
    ): Result<File> {
        val dir = LocalStore.albumDir(item.albumId)
        dir.mkdirs()
        if (albumName != null) LocalStore.rememberAlbumName(item.albumId, albumName)
        return requestFile(
            Msg.build(MsgType.DOWNLOAD_MEDIA, 0L, "mediaId" to item.id),
            dir, item.fileName,
            timeoutMs = transferTimeout(item.sizeBytes),
            onProgress = onProgress
        )
    }
}
