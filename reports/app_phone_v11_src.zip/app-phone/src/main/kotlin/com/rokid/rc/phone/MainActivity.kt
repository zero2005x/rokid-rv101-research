package com.rokid.rc.phone

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.rokid.rc.phone.ui.AlbumsFragment
import com.rokid.rc.phone.ui.LocalFragment
import com.rokid.rc.phone.ui.RemoteFragment
import kotlinx.coroutines.launch

/**
 * 單一 Activity：承載底部導覽（遙控 / 相簿 / 本機），
 * 並集中管理藍牙連線、權限與「選擇眼鏡」。
 */
class MainActivity : AppCompatActivity() {

    private var shownTag = "remote"

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra("tab")?.let { show(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Remote.ensureInit(applicationContext)
        requestBlePermissions()

        findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNav)
            .setOnItemSelectedListener { item ->
                when (item.itemId) {
                    R.id.nav_albums -> show("albums")
                    R.id.nav_local -> show("local")
                    else -> show("remote")
                }
                true
            }
        intent.getStringExtra("tab")?.let { tab -> show(tab); return }
        show("remote")
    }

    private fun show(tag: String) {
        if (tag == shownTag) return
        val fm = supportFragmentManager
        val tx = fm.beginTransaction()
        var target = fm.findFragmentByTag(tag)
        if (target == null) {
            target = when (tag) {
                "albums" -> AlbumsFragment()
                "local" -> LocalFragment()
                else -> RemoteFragment()
            }
            tx.add(R.id.navHost, target, tag)
        } else {
            tx.show(target)
        }
        listOf("remote", "albums", "local").filter { it != tag }.forEach { t ->
            fm.findFragmentByTag(t)?.let { if (it.isAdded) tx.hide(it) }
        }
        tx.commitAllowingStateLoss()
        shownTag = tag
        when (tag) {
            "albums" -> (target as? AlbumsFragment)?.refresh()
            "local" -> (target as? LocalFragment)?.refresh()
            else -> (target as? RemoteFragment)?.refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!Remote.isConnected) autoConnectIfPossible()
    }

    /** 開啟 App 自動連到已配對、名稱含 Glasses/Rokid 的眼鏡。 */
    fun autoConnectIfPossible() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        if (!adapter.isEnabled) return
        val devices = try {
            adapter.bondedDevices.toList()
        } catch (e: Exception) {
            emptyList()
        }
        if (devices.isEmpty()) return
        val target = devices.firstOrNull {
            val n = it.name ?: ""
            n.contains("Glasses", true) || n.contains("Rokid", true)
        } ?: devices.first()
        lifecycleScope.launch { connect(target) }
    }

    /** 顯示「選擇眼鏡」對話框（未連線時）。 */
    fun pickDevice() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null || !adapter.isEnabled) {
            toast("請先開啟藍牙")
            return
        }
        val devices = try {
            adapter.bondedDevices.toList()
        } catch (e: Exception) {
            emptyList()
        }
        if (devices.isEmpty()) {
            toast("沒有已配對的藍牙設備，請先在系統藍牙設定中配對眼鏡")
            return
        }
        val names = devices.map { "${it.name ?: "unknown"} (${it.address})" }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.conn_pick_title)
            .setItems(names) { _, which ->
                val d = devices[which]
                lifecycleScope.launch { connect(d) }
            }
            .show()
    }

    suspend fun connect(device: BluetoothDevice) {
        Remote.connect(device).fold(
            onSuccess = { refreshAllFragments() },
            onFailure = { e -> toast("連線失敗: ${e.message}") }
        )
    }

    fun disconnect() {
        Remote.disconnect()
        refreshAllFragments()
    }

    /** 連線狀態改變後叫各 Fragment 重新整理。 */
    fun refreshAllFragments() {
        val fm = supportFragmentManager
        (fm.findFragmentByTag("remote") as? RemoteFragment)?.onConnectionChanged()
        (fm.findFragmentByTag("albums") as? AlbumsFragment)?.onConnectionChanged()
        (fm.findFragmentByTag("local") as? LocalFragment)?.onConnectionChanged()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        ) {
            autoConnectIfPossible()
        }
    }

    private fun requestBlePermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            needed += Manifest.permission.BLUETOOTH_CONNECT
            needed += Manifest.permission.BLUETOOTH_SCAN
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        /** 以 MediaActivity 開啟眼鏡端某相簿。 */
        fun openRemoteAlbum(from: android.app.Activity, albumId: String, albumName: String) {
            from.startActivity(
                Intent(from, MediaActivity::class.java)
                    .putExtra("mode", "remote")
                    .putExtra("albumId", albumId)
                    .putExtra("albumName", albumName)
            )
        }

        /** 以 MediaActivity 開啟本機相簿。 */
        fun openLocalAlbum(from: android.app.Activity, albumId: String, albumName: String) {
            from.startActivity(
                Intent(from, MediaActivity::class.java)
                    .putExtra("mode", "local")
                    .putExtra("albumId", albumId)
                    .putExtra("albumName", albumName)
            )
        }
    }
}
