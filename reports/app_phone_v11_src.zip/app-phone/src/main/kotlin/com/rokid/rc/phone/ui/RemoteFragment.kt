package com.rokid.rc.phone.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import com.rokid.rc.phone.MainActivity
import com.rokid.rc.phone.R
import com.rokid.rc.phone.Remote
import com.rokid.rc.shared.protocol.Msg
import com.rokid.rc.shared.protocol.MsgType
import com.rokid.rc.shared.protocol.RootMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** 遙控分頁：連線卡、拍攝、LED、進階（root/ghostlock）控制。 */
class RemoteFragment : Fragment() {

    private var rootV: View? = null
    private var recording = false
    private var syncing = false
    private var advancedOpen = false
    private val ledColorState = mutableMapOf("white" to true, "green" to true, "blue" to true, "red" to true)
    private var refreshJob: Job? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_remote, container, false)
        rootV = v
        Remote.ensureInit(requireContext().applicationContext)

        val activity = requireActivity() as MainActivity

        v.findViewById<View>(R.id.btnConnect).setOnClickListener {
            if (Remote.isConnected) {
                log("已斷線")
                activity.disconnect()
            } else {
                activity.pickDevice()
            }
        }

        v.findViewById<View>(R.id.btnPhoto).setOnClickListener {
            if (!Remote.isConnected) { toast("尚未連線眼鏡"); return@setOnClickListener }
            launchUi {
                log("拍照中…")
                Remote.capturePhoto().fold(
                    onSuccess = { m -> log("✓ 已拍照 ${m.fileName}") },
                    onFailure = { e -> log("✗ 拍照失敗 ${e.message}") }
                )
            }
        }

        v.findViewById<View>(R.id.btnVideo).setOnClickListener {
            if (!Remote.isConnected) { toast("尚未連線眼鏡"); return@setOnClickListener }
            launchUi {
                val btn = v.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnVideo)
                if (!recording) {
                    Remote.startVideo().fold(
                        onSuccess = {
                            recording = true
                            btn.setText(R.string.btn_video_stop)
                            btn.setIconResource(R.drawable.ic_stop)
                            log("● 錄影中")
                        },
                        onFailure = { e -> log("✗ 錄影失敗 ${e.message}") }
                    )
                } else {
                    Remote.stopVideo().fold(
                        onSuccess = { m ->
                            recording = false
                            btn.setText(R.string.btn_video_start)
                            btn.setIconResource(R.drawable.ic_videocam)
                            log("✓ 已存影片 ${m.fileName}")
                        },
                        onFailure = { e ->
                            recording = false
                            btn.setText(R.string.btn_video_start)
                            log("✗ 停止失敗 ${e.message}")
                        }
                    )
                }
            }
        }

        // ghostlock / root / LED 開關（syncing 期間不觸發）
        v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swGhost)
            .setOnCheckedChangeListener { _, checked ->
                if (syncing) return@setOnCheckedChangeListener
                launchUi {
                    Remote.setGhostlock(checked).onFailure { e ->
                        log("ghostlock 設定失敗 ${e.message}")
                        syncing = true
                        (rootV?.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swGhost))?.isChecked = !checked
                        syncing = false
                    }
                }
            }
        v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swRootAuto)
            .setOnCheckedChangeListener { _, checked ->
                if (syncing) return@setOnCheckedChangeListener
                launchUi {
                    val mode = if (checked) RootMode.AUTO else RootMode.MANUAL
                    Remote.setRootMode(mode).onFailure { e ->
                        log("root 模式設定失敗 ${e.message}")
                        syncing = true
                        (rootV?.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swRootAuto))?.isChecked = !checked
                        syncing = false
                    }
                }
            }
        v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swLed)
            .setOnCheckedChangeListener { _, checked ->
                if (syncing) return@setOnCheckedChangeListener
                ledColorState["white"] = checked
                launchUi {
                    log(if (checked) "開啟隱私指示燈…" else "關閉隱私指示燈…")
                    Remote.setLed(checked).fold(
                        onSuccess = { log(if (checked) "✓ 指示燈：亮" else "✓ 指示燈：熄") },
                        onFailure = { e ->
                            log("✗ LED 設定失敗 ${e.message}")
                            syncing = true
                            (rootV?.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swLed))?.isChecked = !checked
                            syncing = false
                        }
                    )
                }
            }

        // 顏色 chips
        bindChip(v, R.id.chipLedW, "white")
        bindChip(v, R.id.chipLedG, "green")
        bindChip(v, R.id.chipLedB, "blue")
        bindChip(v, R.id.chipLedR, "red")

        v.findViewById<View>(R.id.btnAcquireRoot).setOnClickListener {
            launchUi {
                log("取得 root 中（可能需數分鐘）…")
                Remote.acquireRoot().fold(
                    onSuccess = { ok -> log(if (ok) "✓ root 已就緒" else "✗ root 取得失敗") },
                    onFailure = { e -> log("✗ root 失敗 ${e.message}") }
                )
            }
        }
        v.findViewById<View>(R.id.btnDeviceInfo).setOnClickListener {
            launchUi {
                log("查詢裝置資訊…")
                Remote.deviceInfo().fold(
                    onSuccess = { info ->
                        val s = StringBuilder()
                        s.append("SELinux: ").append(info.optString("selinux")).append('\n')
                        s.append("root: ").append(info.optBoolean("rootAcquired")).append('\n')
                        s.append("ghostlock: ").append(info.optBoolean("ghostlockEnabled")).append('\n')
                        s.append("mode: ").append(info.optString("rootMode"))
                        log(s.toString())
                    },
                    onFailure = { e -> log("✗ 查詢失敗 ${e.message}") }
                )
            }
        }

        v.findViewById<View>(R.id.tvAdvancedToggle).setOnClickListener {
            advancedOpen = !advancedOpen
            v.findViewById<View>(R.id.llAdvanced).visibility =
                if (advancedOpen) View.VISIBLE else View.GONE
            (v.findViewById<View>(R.id.tvAdvancedToggle) as TextView).text =
                getString(if (advancedOpen) R.string.btn_advanced_hide else R.string.btn_advanced_show)
        }

        // 連線事件 → 更新 UI
        Remote.client.onDisconnected = { activity.runOnUiThread { refresh() } }
        Remote.client.onPush = { o ->
            if (Msg.type(o) == MsgType.PROGRESS) {
                activity.runOnUiThread {
                    log("[進度] ${Msg.string(o, "message")}")
                }
            }
        }

        refresh()
        return v
    }

    private fun bindChip(v: View, id: Int, color: String) {
        val chip = v.findViewById<Chip>(id)
        chip.setOnCheckedChangeListener { _, checked ->
            if (syncing) return@setOnCheckedChangeListener
            ledColorState[color] = checked
            launchUi {
                log("${colorLabel(color)}燈 ${if (checked) "亮" else "熄"}…")
                Remote.setLed(checked, color).fold(
                    onSuccess = { log("✓ ${colorLabel(color)}燈：${if (checked) "亮" else "熄"}") },
                    onFailure = { e ->
                        log("✗ ${color}燈失敗 ${e.message}")
                        syncing = true
                        chip.isChecked = !checked
                        syncing = false
                    }
                )
            }
        }
    }

    private fun colorLabel(color: String): String = when (color) {
        "white" -> "白"
        "green" -> "綠"
        "blue" -> "藍"
        else -> "紅"
    }

    override fun onDestroyView() {
        Remote.client.onPush = null
        Remote.client.onDisconnected = null
        refreshJob?.cancel()
        rootV = null
        super.onDestroyView()
    }

    fun onConnectionChanged() = refresh()

    /** 切到本分頁 / 連線狀態改變時呼叫。 */
    fun refresh() {
        val v = rootV ?: return
        refreshJob?.cancel()
        refreshJob = viewLifecycleOwner.lifecycleScope.launch {
            val dot = v.findViewById<View>(R.id.vConnDot)
            val deviceName = Remote.device?.name
            if (Remote.isConnected) {
                dot.setBackgroundColor(Color.GREEN)
                v.findViewById<TextView>(R.id.tvDevice).text = deviceName ?: getString(R.string.conn_no_device)
                v.findViewById<TextView>(R.id.tvConnState).text = getString(R.string.conn_connected)
                (v.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnConnect)).text =
                    getString(R.string.btn_disconnect)
                loadStatus(v)
            } else {
                dot.setBackgroundColor(Color.GRAY)
                v.findViewById<TextView>(R.id.tvDevice).text =
                    deviceName ?: getString(R.string.conn_no_device)
                v.findViewById<TextView>(R.id.tvConnState).text = getString(R.string.conn_disconnected)
                (v.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnConnect)).text =
                    getString(R.string.btn_connect)
                v.findViewById<View>(R.id.tvSummary).visibility = View.GONE
            }
        }
    }

    private suspend fun loadStatus(v: View) {
        Remote.status().onSuccess { s ->
            syncing = true
            (v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swGhost)).isChecked = s.ghostlockEnabled
            (v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swRootAuto)).isChecked = s.rootMode == RootMode.AUTO.name
            (v.findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.swLed)).isChecked = s.ledOn
            ledColorState["white"] = s.ledOn
            syncing = false
            val sum = "相簿 ${s.albumCount} · 媒體 ${s.mediaCount} · root ${if (s.rootAcquired) "✓" else "—"} · ghostlock ${if (s.ghostlockEnabled) "開" else "關"}"
            v.findViewById<TextView>(R.id.tvSummary).text = sum
            v.findViewById<View>(R.id.tvSummary).visibility = View.VISIBLE
        }
    }

    private fun launchUi(block: suspend () -> Unit) {
        viewLifecycleOwner.lifecycleScope.launch { block() }
    }

    private fun log(msg: String) {
        val tv = rootV?.findViewById<TextView>(R.id.tvLog) ?: return
        val prev = tv.text.toString()
        val line = if (prev.isEmpty()) msg else "$prev\n$msg"
        tv.text = line.takeLast(1200)
    }

    private fun toast(msg: String) {
        (activity as? MainActivity)?.toast(msg)
    }
}
