package com.rokid.rc.phone

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.rokid.rc.shared.protocol.RootMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Debug 用廣播接收器：讓 `adb shell am broadcast` 能觸發遠端指令，
 * 便於自動化驗證（MIUI 封鎖了 shell 的 input 注入）。
 */
class DebugReceiver : BroadcastReceiver() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        Remote.ensureInit(context.applicationContext)
        val cmd = intent.getStringExtra("cmd") ?: return
        Log.i(TAG, "onReceive cmd=$cmd connected=${Remote.client.connected}")
        scope.launch {
            try {
                Log.i(TAG, "executing $cmd connected=${Remote.client.connected}")
                when (cmd) {
                    "SET_LED" -> Log.i(TAG, "SET_LED result=${Remote.setLed(intent.getBooleanExtra("on", true), intent.getStringExtra("color") ?: "white")}")
                    "SET_GHOSTLOCK" -> Log.i(TAG, "SET_GHOSTLOCK result=${Remote.setGhostlock(intent.getBooleanExtra("enabled", true))}")
                    "CAPTURE_PHOTO" -> Log.i(TAG, "CAPTURE_PHOTO result=${Remote.capturePhoto().isSuccess}")
                    "START_VIDEO" -> Log.i(TAG, "START_VIDEO result=${Remote.startVideo().isSuccess}")
                    "STOP_VIDEO" -> Log.i(TAG, "STOP_VIDEO result=${Remote.stopVideo().isSuccess}")
                    "ACQUIRE_ROOT" -> Log.i(TAG, "ACQUIRE_ROOT result=${Remote.acquireRoot()}")
                    "SET_ROOT_MODE" ->
                        Remote.setRootMode(if (intent.getBooleanExtra("auto", false)) RootMode.AUTO else RootMode.MANUAL)
                    "GET_DEVICE_INFO" -> Log.i(TAG, "DEVICE_INFO=${Remote.deviceInfo().getOrNull()}")
                    "DELETE_MEDIA" -> Log.i(TAG, "DELETE_MEDIA=${Remote.deleteMedia(intent.getStringExtra("mediaId") ?: "")}")
                    "TEST_CHAIN" -> testMediaChain()
                    "LIST_MEDIA_INFO" -> {
                        val albums = Remote.listAlbums().getOrNull() ?: emptyList()
                        val album = albums.firstOrNull { it.id == intent.getStringExtra("albumId") } ?: albums.firstOrNull()
                        if (album != null) {
                            val items = Remote.listMedia(album.id).getOrNull() ?: emptyList()
                            val head = items.take(3).map {
                                "${it.fileName}|${it.id}|${it.type}|${it.sizeBytes}|${it.durationMs}"
                            }
                            Log.i(TAG, "LIST_MEDIA_INFO album=${album.id} total=${items.size} head=$head")
                        } else Log.i(TAG, "LIST_MEDIA_INFO no-album")
                    }
                    "OPEN_TAB" -> {
                        val tab = intent.getStringExtra("tab") ?: "remote"
                        val i = Intent(context, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            .putExtra("tab", tab)
                        context.startActivity(i)
                        Log.i(TAG, "OPEN_TAB=$tab")
                    }
                    "OPEN_ALBUM" -> {
                        val i = Intent(context, MediaActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .putExtra("mode", intent.getStringExtra("mode") ?: "remote")
                            .putExtra("albumId", intent.getStringExtra("albumId") ?: "")
                            .putExtra("albumName", intent.getStringExtra("albumName") ?: "")
                        context.startActivity(i)
                        Log.i(TAG, "OPEN_ALBUM done")
                    }
                    "OPEN_VIEWER" -> {
                        val mode = intent.getStringExtra("mode") ?: "remote"
                        val i = Intent(context, ViewerActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            .putExtra("mode", mode)
                        if (mode == "local") {
                            i.putExtra("path", intent.getStringExtra("path") ?: "")
                            i.putExtra("mime", intent.getStringExtra("mime") ?: "image/jpeg")
                            i.putExtra("fileName", intent.getStringExtra("fileName") ?: "")
                        } else {
                            i.putExtra("mediaId", intent.getStringExtra("mediaId") ?: "")
                            i.putExtra("albumId", intent.getStringExtra("albumId") ?: "")
                            i.putExtra("albumName", intent.getStringExtra("albumName") ?: "")
                            i.putExtra("type", intent.getStringExtra("type") ?: "PHOTO")
                            i.putExtra("mime", intent.getStringExtra("mime") ?: "image/jpeg")
                            i.putExtra("fileName", intent.getStringExtra("fileName") ?: "")
                            i.putExtra("sizeBytes", intent.getLongExtra("sizeBytes", 0L))
                            i.putExtra("createdAt", intent.getLongExtra("createdAt", 0L))
                        }
                        context.startActivity(i)
                        Log.i(TAG, "OPEN_VIEWER done")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "execute $cmd failed", e)
            }
        }
    }

    private suspend fun testMediaChain() {
        val albums = Remote.listAlbums().getOrNull() ?: emptyList()
        Log.i(TAG, "TEST_CHAIN albums=${albums.map { it.name + "(" + it.mediaCount + ")" }}")
        if (albums.isEmpty()) {
            Log.i(TAG, "TEST_CHAIN 沒有相簿，中止")
            return
        }
        val album = albums.first()
        val media = Remote.listMedia(album.id).getOrNull() ?: emptyList()
        Log.i(TAG, "TEST_CHAIN media(${album.name}) count=${media.size}")
        if (media.isEmpty()) {
            Log.i(TAG, "TEST_CHAIN 相簿內無媒體，中止")
            return
        }
        val first = media.first()
        Log.i(TAG, "TEST_CHAIN 縮圖=${Remote.getThumbnail(first.id)}")
        Log.i(TAG, "TEST_CHAIN 下載=${Remote.downloadMedia(first)}")
    }

    companion object {
        private const val TAG = "DebugReceiver"
    }
}
